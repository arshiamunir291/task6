<div class="row D_step1">
    <div class="col-md-6">
        <img src="{{ asset('app-assets/images/dash_images/step-1.svg') }}" alt="">
    </div>
    <div class="col-md-6">
        <div class="InnerText">
            <h3 class="mb-2">Welcome to Quibit</h3>
            <h3 class="Txt_blue mb-2">Quibit Dashboard for manage <br> your Transactions</h3>
            <p>Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur</p>
        </div>
    </div>
    <div class="NextBtns_botsWrap">
        <div class="NextBtns_bots justify-content-between">
            <div class="DotsLeft">
                <span class="active"></span>
                <span></span>
                <span></span>
            </div>
            <div class="InnerBtns">
                <button type="button" class="backBtn" disabled>Back</button>
                <button type="button" class="startedBtn next-step Get_StartedBtn">Let’s get started</button>
            </div>
        </div>
    </div>
</div>